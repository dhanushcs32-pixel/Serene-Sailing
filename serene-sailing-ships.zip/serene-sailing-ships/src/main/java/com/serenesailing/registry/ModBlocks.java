package com.serenesailing.registry;

import com.serenesailing.SereneSailing;
import com.serenesailing.block.RudderBlock;
import com.serenesailing.block.SailBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModBlocks {

    public static final DeferredRegister.Blocks BLOCKS =
            DeferredRegister.createBlocks(SereneSailing.MOD_ID);

    /**
     * A basic canvas sail. Placed as part of a Sable sub-level, it should
     * contribute directional thrust proportional to wind exposure and
     * sail area once wired into Aeronautics' propulsion pipeline.
     * Stubbed here as a plain block first so the pack boots; physics
     * behaviour lives in {@link com.serenesailing.sail.SailPhysics}
     * (not yet implemented - next step).
     */
    public static final DeferredBlock<Block> CANVAS_SAIL = BLOCKS.register(
            "canvas_sail",
            () -> new SailBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.SAND)
                    .strength(1.0F, 3.0F)
                    .sound(SoundType.WOOL)
                    .noOcclusion())
    );

    /**
     * A ship's rudder. Intended to be the steering input for a Sable
     * sub-level, analogous to how Aeronautics uses control surfaces for
     * pitch/yaw on airships. Stubbed as a plain block first.
     */
    public static final DeferredBlock<Block> RUDDER = BLOCKS.register(
            "rudder",
            () -> new RudderBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.WOOD)
                    .strength(2.0F, 6.0F)
                    .sound(SoundType.WOOD)
                    .noOcclusion())
    );
}
