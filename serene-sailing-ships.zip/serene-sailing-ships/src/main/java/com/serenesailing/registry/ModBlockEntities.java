package com.serenesailing.registry;

import com.serenesailing.SereneSailing;
import net.minecraft.core.registries.Registries;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Placeholder for block entities. Sails/rudders may not need one at all if
 * their state (trim angle, deployed/furled) can live in BlockState -
 * simpler and cheaper. Only add a BlockEntity here if you need per-block
 * data too large/variable for BlockState (e.g. continuously variable trim
 * angle with smooth interpolation, damage/wear tracking).
 */
public class ModBlockEntities {

    public static final DeferredRegister<net.minecraft.world.level.block.entity.BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, SereneSailing.MOD_ID);

    // Example (uncomment and implement once SailBlockEntity exists):
    //
    // public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<SailBlockEntity>> SAIL =
    //         BLOCK_ENTITIES.register("canvas_sail", () -> BlockEntityType.Builder.of(
    //                 SailBlockEntity::new, ModBlocks.CANVAS_SAIL.get()
    //         ).build(null));
}
