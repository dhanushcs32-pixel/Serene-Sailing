package com.serenesailing.registry;

import com.serenesailing.SereneSailing;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModItems {

    public static final DeferredRegister.Items ITEMS =
            DeferredRegister.createItems(SereneSailing.MOD_ID);

    public static final DeferredItem<Item> CANVAS_SAIL = ITEMS.registerSimpleBlockItem(
            "canvas_sail", ModBlocks.CANVAS_SAIL
    );

    public static final DeferredItem<Item> RUDDER = ITEMS.registerSimpleBlockItem(
            "rudder", ModBlocks.RUDDER
    );
}
