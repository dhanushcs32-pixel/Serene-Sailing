package com.serenesailing.config;

import net.neoforged.neoforge.common.ModConfigSpec;

/**
 * Common config for ship physics tuning. Kept deliberately small at this
 * stage - expand as sail/rudder mechanics get prototyped. This is separate
 * from the "world generation" config in the future ocean/island mod
 * (idea #3 in the state file); this one only governs propulsion/handling.
 */
public class SailingConfig {

    public static final ModConfigSpec SPEC;

    public static final ModConfigSpec.DoubleValue SAIL_FORCE_MULTIPLIER;
    public static final ModConfigSpec.DoubleValue RUDDER_TURN_RATE;
    public static final ModConfigSpec.DoubleValue MIN_WIND_SPEED_FOR_THRUST;
    public static final ModConfigSpec.BooleanValue WEATHER2_WIND_INTEGRATION;

    static {
        ModConfigSpec.Builder builder = new ModConfigSpec.Builder();

        builder.comment("Ship sail and rudder tuning").push("sailing");

        SAIL_FORCE_MULTIPLIER = builder
                .comment("Global multiplier applied to sail-generated thrust. 1.0 = default balance.")
                .defineInRange("sailForceMultiplier", 1.0, 0.0, 10.0);

        RUDDER_TURN_RATE = builder
                .comment("Degrees per tick a rudder can turn a sub-level at full deflection.")
                .defineInRange("rudderTurnRate", 1.5, 0.01, 30.0);

        MIN_WIND_SPEED_FOR_THRUST = builder
                .comment("Minimum wind speed (in Weather 2 units, if integration is enabled) before sails generate any thrust.")
                .defineInRange("minWindSpeedForThrust", 0.1, 0.0, 100.0);

        WEATHER2_WIND_INTEGRATION = builder
                .comment(
                        "If true, sail thrust is driven by Weather 2's wind/storm system.",
                        "If false, sails use a constant fallback wind model (useful for testing without Weather 2 loaded)."
                )
                .define("weather2WindIntegration", true);

        builder.pop();

        SPEC = builder.build();
    }
}
