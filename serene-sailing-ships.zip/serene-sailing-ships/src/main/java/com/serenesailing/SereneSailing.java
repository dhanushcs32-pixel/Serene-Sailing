package com.serenesailing;

import com.serenesailing.config.SailingConfig;
import com.serenesailing.registry.ModBlockEntities;
import com.serenesailing.registry.ModBlocks;
import com.serenesailing.registry.ModItems;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.common.NeoForge;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Serene Sailing: Ship Rigging
 * <p>
 * An addon mod, not a fork. Depends on Sable (physics sub-levels) and
 * Create Aeronautics (contraption/propulsion/control framework) and adds
 * sails, rudders, and wind-driven ship propulsion on top of them.
 * <p>
 * See the Serene Sailing state file, Session 1, for the architecture
 * decision behind piggybacking rather than forking.
 */
@Mod(SereneSailing.MOD_ID)
public class SereneSailing {

    public static final String MOD_ID = "serenesailing";
    public static final Logger LOGGER = LoggerFactory.getLogger(SereneSailing.class);

    public SereneSailing(IEventBus modEventBus, ModContainer modContainer) {
        // Registries
        ModBlocks.BLOCKS.register(modEventBus);
        ModItems.ITEMS.register(modEventBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modEventBus);

        modEventBus.addListener(this::commonSetup);

        NeoForge.EVENT_BUS.register(this);

        modContainer.registerConfig(ModConfig.Type.COMMON, SailingConfig.SPEC);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        LOGGER.info("Serene Sailing: Ship Rigging - initializing sail/rudder registration on top of Sable + Create Aeronautics");
    }
}
