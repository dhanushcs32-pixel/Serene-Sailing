package com.serenesailing.block;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;

/**
 * A rudder block. Currently a plain, inert block so the mod loads cleanly.
 * <p>
 * TODO (next implementation pass):
 * <ol>
 *   <li>Find Aeronautics' existing control-surface / steering-input
 *       handling (used for airship pitch/yaw or Offroad's wheel steering)
 *       and hook into the same input pipeline rather than writing a new
 *       one - keeps controls consistent for players who already fly
 *       Aeronautics airships.</li>
 *   <li>Apply a torque to the Sable sub-level proportional to
 *       {@code SailingConfig.RUDDER_TURN_RATE} and current forward
 *       velocity (a stationary ship's rudder should do ~nothing, matching
 *       real sailing behaviour and avoiding "helicopter spin in place"
 *       exploits).</li>
 *   <li>Decide input binding: dedicated keybind vs. reusing Aeronautics'
 *       existing steering keys when the player is "at the helm" (standing
 *       near/interacting with the rudder or a separate helm/wheel block -
 *       consider adding a Helm block as a follow-up rather than making
 *       the rudder itself the input point).</li>
 * </ol>
 */
public class RudderBlock extends Block {
    public RudderBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }
}
