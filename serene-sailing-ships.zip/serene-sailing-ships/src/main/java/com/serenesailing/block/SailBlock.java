package com.serenesailing.block;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;

/**
 * A sail block. Currently a plain, inert block so the mod loads cleanly.
 * <p>
 * TODO (next implementation pass, once Sable/Aeronautics jars are resolved
 * in your IDE and you can see their real API surface):
 * <ol>
 *   <li>Look at how Aeronautics' propeller/thruster blocks register
 *       themselves as a "force contributor" on a Sable sub-level - sails
 *       should follow the same pattern rather than inventing a new one.</li>
 *   <li>Compute thrust as a function of: sail area (block count in a
 *       contiguous sail structure), angle of the sail plane relative to
 *       wind direction, and wind speed (see {@link com.serenesailing.sail.SailPhysics}).</li>
 *   <li>Read wind direction/speed from Weather 2 if
 *       {@code SailingConfig.WEATHER2_WIND_INTEGRATION} is true, else fall
 *       back to a constant test wind vector.</li>
 *   <li>Decide whether trim angle (facing into/away from wind) is
 *       player-adjustable (right-click to luff/trim) or fixed - this is a
 *       gameplay decision, not just a technical one, worth deciding before
 *       writing the BlockEntity.</li>
 * </ol>
 */
public class SailBlock extends Block {
    public SailBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }
}
